package com.example.hiten.trexrunner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Random;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.support.constraint.solver.widgets.Rectangle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Random;

public class GameEngine extends SurfaceView implements Runnable {

    // Android debug variables
    final static String TAG="TEX-RUNNER";

    // screen size
    int screenHeight;
    int screenWidth;

    // game state
    boolean gameIsRunning;

    // threading
    Thread gameThread;


    // drawing variables
    SurfaceHolder holder;
    Canvas canvas;
    Paint paintbrush;
    Bitmap background;
    Bitmap horizontal;
    Bitmap dinosaur;
    Bitmap dinosaur1;
    Bitmap cactus;

    int direction = 0;

    ArrayList<Bitmap> bitmapCactus = new ArrayList<Bitmap>();

    //Touch variables
    int movement = 0;


    //Media Variables
    MediaPlayer mp;

    // Game gravity
    double positionY,positionX;
    float gravity = 0.5f;
    int v0 = 30;

    // -----------------------------------
    // GAME SPECIFIC VARIABLES
    // -----------------------------------



    public GameEngine(Context context, int w, int h) {
        super(context);

        mp=MediaPlayer.create(context,R.raw.press);

        this.holder = this.getHolder();
        this.paintbrush = new Paint();

        this.screenWidth = w;
        this.screenHeight = h;

        background = BitmapFactory.decodeResource(context.getResources(),R.drawable.background);
        background = Bitmap.createScaledBitmap(background,this.screenWidth,this.screenHeight,false);

        horizontal = BitmapFactory.decodeResource(context.getResources(),R.drawable.horizon);
        horizontal = Bitmap.createScaledBitmap(horizontal,this.screenWidth,this.screenHeight/(25),false);

        dinosaur = BitmapFactory.decodeResource(context.getResources(),R.drawable.dinosaur1);
        dinosaur = Bitmap.createScaledBitmap(dinosaur,180,200,false);

        dinosaur1 = BitmapFactory.decodeResource(context.getResources(),R.drawable.dinosaur2);
        dinosaur1 = Bitmap.createScaledBitmap(dinosaur1,180,200,false);

        cactus = BitmapFactory.decodeResource(context.getResources(),R.drawable.cactus_large);
        cactus = Bitmap.createScaledBitmap(cactus,480,200,false);

        bitmapCactus.add(cactus);
        bitmapCactus.add(dinosaur);

        positionX = dinosaur.getWidth();
        positionY = 815;
//
//        Log.d("BITMAP","ARRAY" + dinosaur.getHeight());
//        Log.d("BITMAP","ARRAY" + dinosaur.getWidth());

        this.printScreenInfo();

    }



    private void printScreenInfo() {

        Log.d(TAG, "Screen (w, h) = " + this.screenWidth + "," + this.screenHeight);
    }




    private void spawnEnemyShips() {
        Random random = new Random();

        //@TODO: Place the enemies in a random location

    }

    // ------------------------------
    // GAME STATE FUNCTIONS (run, stop, start)
    // ------------------------------
    @Override
    public void run() {
        while (gameIsRunning == true) {
            this.updatePositions();
            this.redrawSprites();
            this.setFPS();
        }
    }


    public void pauseGame() {
        gameIsRunning = false;
        try {
            gameThread.join();
        } catch (InterruptedException e) {
            // Error
        }
    }

    public void startGame() {
        gameIsRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    // ------------------------------
    // GAME ENGINE FUNCTIONS
    // - update, draw, setFPS
    // ------------------------------

    //Speed variable
    int bgx = 0;
    int bgRightside = 0;

    int hbgx = 0;
    int hbgRightside = 0;

    int cactx = 2392;
    int cactRightside  = 0;


    //For Image-1
    int SPEED = 0;

    //For image-2
    int SPEED_2 = 0;


    public void updatePositions() {
//        Log.d("WIDTH","Wid" + screenWidth);

        if(movement == 1) {
            this.ImageMovement();
            Log.d("data","tpouch");
        }

        else {
          Log.d("data","jump");
        }
    }



    public void ImageMovement() {


        bgx = bgx - SPEED;

        bgRightside = this.background.getWidth() - (- this.bgx);

        if(bgRightside <= 0){
            this.bgx = 0;
        }

        hbgx = hbgx -SPEED_2;
        hbgRightside = this.horizontal.getWidth() - (-this.hbgx);

        if(hbgRightside <= 0) {
            this.hbgx = 0;
        }


        cactx = cactx - 25;
        cactRightside = this.cactus.getWidth() - (-this.cactx);
        if(cactRightside <=0) {
            this.cactx = 2392;
        }

        if(direction == 0) {
            Log.d("ghfjfd", "direction0");
            //make a jump
            positionY += v0 * 3;
            v0 += gravity;

//            positionY = 815;
        }





    }



    public void redrawSprites() {
        if (this.holder.getSurface().isValid()) {
            this.canvas = this.holder.lockCanvas();

            //----------------

            // configure the drawing tools
            this.canvas.drawColor(Color.BLACK);
            paintbrush.setColor(Color.BLACK);

            canvas.drawBitmap(this.background,bgx,0,null);
            canvas.drawBitmap(this.background,bgRightside,0,null);

            canvas.drawBitmap(this.horizontal,hbgx,1000,null);
            canvas.drawBitmap(this.horizontal,hbgRightside,1000,null);



            canvas.drawBitmap(dinosaur,100, (float) positionY,paintbrush);


            canvas.drawBitmap(this.cactus,cactx,815,null);


          //  canvas.drawBitmap(this.cactus,cactRightside,815,null);


            //this.canvas.drawText("HI");
            paintbrush.setColor(Color.BLUE);
            canvas.drawText("HI",160,160,paintbrush);




            //@TODO: Draw the player

            //@TODO: Draw the enemy

            //----------------
            this.holder.unlockCanvasAndPost(canvas);
        }
    }

    public void setFPS() {
        try {
            gameThread.sleep(50);
        }
        catch (Exception e) {

        }
    }

    // ------------------------------
    // USER INPUT FUNCTIONS
    // ------------------------------
    int direct = 0;
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int userAction = event.getActionMasked();
        //@TODO: What should happen when person touches the screen?
        if (userAction == MotionEvent.ACTION_UP) {
            this.SPEED = 25;
            this.SPEED_2 = 150;

            movement = 1;


            this.updatePositions();
//            if(direction == -1) {
//                v0 = -12;
//            } else {
//                v0 = 12;
//
//            }
            v0 = 12;
            mp.start();
//            direction = -1;
        }
            return true;
        }


}